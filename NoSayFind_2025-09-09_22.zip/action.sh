#!/system/bin/sh
TARGET_FILE="/data/adb/tricky_store/target.txt"
pm list packages | sed -e 's/package://g' -e '/^$/d' > "$TARGET_FILE"
COUNT=$(grep -c . "$TARGET_FILE")
echo "$COUNT个应用被BootLoader隐藏强解锁状态"
"./排除列表.bin" > /dev/null 2>&1