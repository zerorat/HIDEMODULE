#!/system/bin/sh
sleep 1
flower=${0%/*}
cd $flower
chmod 777 -R .
"./main.bin"