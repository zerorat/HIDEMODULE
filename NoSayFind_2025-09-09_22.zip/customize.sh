if [ -d "/data/adb/magisk" ]; then
echo "检测到你是Magisk(或者共存)
1. 如果你是Magisk/Alpha 会被NoSayFind强制切换为白名单授权Root模式 配置在/storage/emulated/0/配置排除.txt 往里面一行一个填入你需要给Root权限的包名 每次按Action(模块的三角形启动按钮刷新排除列表)
2. 如果你是多Root实现共存现在立马刷回原镜像 不然后果自负"

touch /storage/emulated/0/配置排除.txt
fi